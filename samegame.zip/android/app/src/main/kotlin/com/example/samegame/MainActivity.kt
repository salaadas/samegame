package com.example.samegame

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
